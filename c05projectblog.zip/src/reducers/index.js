import { combineReducers } from 'redux';
import user from './user';

const appReducers = combineReducers({
	user
});

export default appReducers;